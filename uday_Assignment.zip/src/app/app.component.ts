import { Component } from '@angular/core';
import { DataModel } from './models/data.model';
import { FormControl, FormGroup, FormArray, FormBuilder } from '@angular/forms';
import { formGroupNameProvider } from '@angular/forms/src/directives/reactive_directives/form_group_name';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  title = 'sampleApp';
  serachQry = "";

  filterText = '';
  columnType = new FormControl();  
  public signupForm: FormGroup;

  columnoptions: string[] = ['FirstName', 'LastName', 'Company', 'Email', 'City'];

  constructor( private formBuilder: FormBuilder) { }

  ngOnInit() {

    
    this.signupForm = new FormGroup({      
        FirstName : new FormControl('FirstName'),
        FirstNameValue : new FormControl(),
        LastName : new FormControl('LastName'),
        LastNameValue : new FormControl(),
        Company : new FormControl('Company'),
        CompanyValue : new FormControl(),
        Email : new FormControl('Email'),
        EmailValue : new FormControl(),
        City : new FormControl('City'),
        CityValue : new FormControl()
    });

    this.signupForm.valueChanges.subscribe(
      (status) => console.log(status)
    );
  }

  getform(): FormGroup {
    const signupForm: FormGroup = this.formBuilder.group({
      Email: new FormControl(),
      Contactno: new FormControl()
    });
    return signupForm;
  }

  onChangeOptions($event){
    debugger;
  }

  dataCollection: DataModel[] = [
    {
      "FirstName": "Andrew",
      "LastName": "Smith",
      "Company": "Accenture",
      "Email": "andrew.s@accenture.com",
      "City": "London"
    },

    {
      "FirstName": "James",
      "LastName": "Peter",
      "Company": "Cognizant",
      "Email": "james.p@cognizant.com",
      "City": "London"
    },
    {
      "FirstName": "Rutvik",
      "LastName": "Patel",
      "Company": "TCS",
      "Email": "rutvik.p@tcs.com",
      "City": "Gandhinagar"
    },
    {
      "FirstName": "Lata",
      "LastName": "Anderson",
      "Company": "Google",
      "Email": "Lata.a@google.com",
      "City": "Chicago"
    },
    {
      "FirstName": "Smarth",
      "LastName": "Dave",
      "Company": "Adobe",
      "Email": "smarth.d@adobe.com",
      "City": "Pune"
    }
  ];

  firstName = new FormControl();
  firstNameList: string[] = this.dataCollection.map((x) => x.FirstName);


  searchData($event: any) {

  }
}




