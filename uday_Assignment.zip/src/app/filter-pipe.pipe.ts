import { Pipe, PipeTransform } from '@angular/core';
import { DataModel } from './models/data.model';
import { NgForm } from '@angular/forms';

@Pipe({
  name: 'filterPipe'
})
export class FilterPipePipe implements PipeTransform {

  transform(value: DataModel[], form: DataModelForm): DataModel[] {
    if (value == null || value.length == 0) {
      return [];
    }
    if (form.CityValue == null && form.CompanyValue == null && form.EmailValue == null
      && form.FirstNameValue == null && form.LastNameValue == null) {
      return [];
    }
    const resultArray: DataModel[] = [];
    for (const item of value) {
      if (item != null) {
        debugger;
        if (
          (form.CityValue == null || form.CityValue.length == 0 || form.CityValue.indexOf(item.City) != -1) &&
          (form.CompanyValue == null || form.CompanyValue.length == 0 || form.CompanyValue.indexOf(item.Company) != -1) &&
          (form.EmailValue == null || form.EmailValue.length == 0 || form.EmailValue.indexOf(item.Email) != -1) &&
          (form.FirstNameValue == null || form.FirstNameValue.length == 0 || form.FirstNameValue.indexOf(item.FirstName) != -1) &&
          (form.LastNameValue == null || form.LastNameValue.length == 0 || form.LastNameValue.indexOf(item.LastName) != -1)
        )
          resultArray.push(item);
      }
    }
    return resultArray;
  }

}


export class DataModelForm {
  constructor(
    public City: "City",
    public CityValue: string[],
    public Company: "Company",
    public CompanyValue: string[],
    public Email: "Email",
    public EmailValue: string[],
    public FirstName: "FirstName",
    public FirstNameValue: string[],
    public LastName: "LastName",
    public LastNameValue: string[]) {
  }
}