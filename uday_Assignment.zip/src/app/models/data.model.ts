export class DataModel {
    constructor(public FirstName: string, public LastName: string, public Company: string,
        public Email: string, public City: string) {}
}